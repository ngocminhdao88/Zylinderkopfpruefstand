"""Defines tests and their order"""

TESTS = ["first", "second", "third", "fourth"]

SKIP = ["first", "third", "fourth"]

