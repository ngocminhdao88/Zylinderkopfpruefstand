# Super Simple Test Sequencer

## Install

```
pip install super-simple-test-sequencer
```

## Create new test sequence

This command creates new empty/template test sequence to test_definitions/ directory.

```
super_simple_test_runner.py 
```

Modify the template at test_definitions/ to create your own sequence.

## Run sequence

```
super_simple_test_runner.py 
```


# More information

See video of the concept (in finnish):
https://youtu.be/x7MCSb7BLW4
